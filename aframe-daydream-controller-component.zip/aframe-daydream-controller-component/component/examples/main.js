require('aframe');
require('../index.js');
